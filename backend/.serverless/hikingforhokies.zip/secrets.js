module.exports = { key: '2d513eabb3mshe028f80c3cb7bdap1191b1jsn28b437ac17aa',
    user: 'geo',
    pass: 'IGIbus7ZVGPFU1HV',
    cluster: 'cluster0-wrh6y.azure.mongodb.net'
}